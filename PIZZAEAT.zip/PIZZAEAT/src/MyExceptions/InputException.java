package MyExceptions;

public class InputException extends Exception {
	public static void InputMismatch() 
	{
		System.out.println("Input Not Valid");
	}

}
