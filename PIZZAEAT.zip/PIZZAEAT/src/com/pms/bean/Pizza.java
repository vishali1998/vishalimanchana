package com.pms.bean;

public class Pizza {
	
		private int pid;
		private String pname;
		private int qty;
		private double price;
		
		public Pizza(){}
		
		public Pizza(int pid, String pname, int qty, double price) {
			this.pid = pid;
			this.pname = pname;
			this.qty = qty;
			this.price = price;
		}
		public int getPid() {
			return pid;
		}

		public void setPid(int pid) {
			this.pid = pid;
		}

		public String getPname() {
			return pname;
		}

		public void setPname(String pname) {
			this.pname = pname;
		}

		public int getQty() {
			return qty;
		}

		public void setQty(int qty) {
			this.qty = qty;
		}

		public double getPrice() {
			return price;
		}

		public void setPrice(double price) {
			this.price = price;
		}
		
		public String toString()
		{
			return pid+"\t"+pname+"\t"+qty+"\t"+price;
		}
		


	}



