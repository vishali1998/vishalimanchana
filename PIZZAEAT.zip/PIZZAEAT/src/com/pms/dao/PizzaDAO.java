package com.pms.dao;

import java.util.List;

import com.pms.bean.Pizza;
	public interface PizzaDAO {
		public void addPizza();
		public Pizza viewPizza(int pid);
		public List<Pizza> viewAllPizza();
		public void updatePizza(int pid);
		public void deletePizza(int pid);
		public void cancelOrder(int pid);
		public void placeOrder(int pid);
		public void bill();
		public void back();
		
	}


