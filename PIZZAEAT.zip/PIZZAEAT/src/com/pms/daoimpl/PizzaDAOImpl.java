package com.pms.daoimpl;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.pms.bean.Pizza;
import com.pms.dao.PizzaDAO;
import com.pms.main.PizzaManagement;

class PizzaAvailabilityException extends RuntimeException{

	public PizzaAvailabilityException(String msg) {
		super(msg);
	}
}
public class PizzaDAOImpl implements PizzaDAO {
	Scanner sc = new Scanner(System.in);
	static List<Pizza> pizzas = new ArrayList<Pizza>();
	static List<Pizza> tempList = new ArrayList<Pizza>();
	Pizza pizza = null;
	
	@Override
	public void addPizza() {
		int i=1;
		while(i==1)
		{
			pizza = new Pizza();
			System.out.println("Enter pizza Number ?");
			pizza.setPid(sc.nextInt());
			System.out.println("Enter pizza Name ?");
			pizza.setPname(sc.next());
			System.out.println("Enter pizza Qty ?");
			pizza.setQty(sc.nextInt());
			System.out.println("Enter pizza Price ?");
			pizza.setPrice(sc.nextDouble());
			pizzas.add(pizza);
			System.out.println("Do you want to add more product press 1 else any number?");
			i = sc.nextInt();
			
		}
		System.out.println("Successfully Products aded...");
		
	}

	@Override
	public Pizza viewPizza(int pid) {
		Pizza p = new Pizza();
		for(Pizza p1:pizzas)
		{
			if(p1.getPid()==pid)
			{
				p=p1;
				break;
			}
		}
		return p;
	}

	@Override
	public List<Pizza> viewAllPizza() {

		return pizzas;
	}

	@Override
	public void updatePizza(int pid) {
		tempList = new ArrayList<Pizza>();
		for(Pizza p2:pizzas)
		{
			if(p2.getPid()==pid)
			{
				System.out.println("Select Your Choice 1.Name 2.Qty  3. Price ");
				int choice = sc.nextInt();
				switch(choice)
				{
				case 1:System.out.println("Enter Updated pizza Name ?");
				       p2.setPname(sc.next());
				       break;
				case 2:System.out.println("Enter Updated pizza Qty ?");
				       p2.setQty(sc.nextInt());
				       break;
				case 3:System.out.println("Enter Updated pizza Price ?");
				       p2.setPrice(sc.nextDouble());
				       break;
				default:System.out.println("Please select your choice range 1-3 only");       
				}
				tempList.add(p2);
				System.out.println("successfully updated");
			}else{
				throw new PizzaAvailabilityException ("pizzaItems not Available with that ID please try with available ID");			
			}
		}
		pizzas = new  ArrayList<Pizza>();
		for(Pizza p3:tempList)
		{
			pizzas.add(p3);
		}
		System.out.println("Successfullu Pizza Updated....");
		
	}

	@Override
	public void deletePizza(int pid) {
		tempList = new ArrayList<Pizza>();
		for(Pizza p2:pizzas)
		{
			if(p2.getPid()==pid)
			{
				
			}else{
				throw new PizzaAvailabilityException ("FoodItems not Available with that ID please try with available ID");
			}
		}
		pizzas = new ArrayList<Pizza>();
		for(Pizza p3:tempList)
		{
			pizzas.add(p3);
		}
		System.out.println("Successfully Pizza Deleted...");
		
	}
	@Override
	public void placeOrder(int pid)
	{
		tempList = new ArrayList<Pizza>();
		Pizza product = new Pizza();
		product.setPid(pid);
		System.out.println("Enter No of Qty ?");
		product.setQty(sc.nextInt());
				for(Pizza p0:pizzas)
		{
			if(p0.getPid()==product.getPid())
			{
				p0.setQty(p0.getQty()-product.getQty());
				tempList.add(p0);
				System.out.println("------------------------------");
				System.out.println("|          BILL              |");
				System.out.println("------------------------------");
				System.out.println("Product Id    :   "+product.getPid());
				System.out.println("Product Name  :   "+p0.getPname());
				System.out.println("Product Qty   :   "+product.getQty());
				System.out.println("Product Price :   "+p0.getPrice());
				System.out.println("-------------------------------");
				System.out.println("Total         :   "+(product.getQty()*p0.getPrice()));
				System.out.println("-------------------------------");
				
			}else{
				throw new PizzaAvailabilityException ("FoodItems not Available with that ID please try with available ID");
			}
		}
		pizzas = new ArrayList<Pizza>();
		for(Pizza p6:tempList)
		{
			pizzas.add(p6);
		}
		
		
		System.out.println("Your Order has been placed....");
		
	}  
	@Override 
	public void cancelOrder(int pid)
	{
		tempList = new ArrayList<Pizza>();
		Pizza product = new Pizza();
		product.setPid(pid);
		System.out.println("Enter No of Qty  ?");
		product.setQty(sc.nextInt());
		
		for(Pizza p8:pizzas)
		{
			if(p8.getPid()==product.getPid())
			{
				p8.setQty(p8.getQty()-product.getQty());
				tempList.add(p8);
				System.out.println("------------------------------");
				System.out.println("|       ORDER CANCELLED        |");
				System.out.println("------------------------------");
				System.out.println("Product Id          :   "+product.getPid());
				System.out.println("Product Name        :   "+p8.getPname());
				System.out.println("Product Qty         :   "+product.getQty());
				System.out.println("Actual Price        :   "+p8.getPrice());
				System.out.println("Cancellation fee    :      0");
				System.out.println("-------------------------------");
				System.out.println("Total               :   "+"0");
				//System.out.println("Total               :   "+(product.getQty()*p8.getPrice()));
				System.out.println("-------------------------------");
				
			}else{
				throw new PizzaAvailabilityException ("FoodItems not Available with that ID please try with available ID");
			}
		}
		pizzas = new ArrayList<Pizza>();
		for(Pizza p9:tempList)
		{
			pizzas.add(p9);
		}
		System.out.println("Your Order has Been Canceled....");
	}

	
	@Override
	public void bill() {
		tempList = new ArrayList<Pizza>();
		Pizza product = new Pizza();
		for(Pizza p4:pizzas)
		{
			System.out.println(p4);
		}
		
		System.out.println("Enter Select Product id ?");
		product.setPid(sc.nextInt());
		System.out.println("Enter No of Qty ?");
		product.setQty(sc.nextInt());
		
		for(Pizza p5:pizzas)
		{
			if(p5.getPid()==product.getPid())
			{
				p5.setQty(p5.getQty()-product.getQty());
				tempList.add(p5);
				System.out.println("------------------------------");
				System.out.println("|          BILL              |");
				System.out.println("------------------------------");
				System.out.println("Product Id    :   "+product.getPid());
				System.out.println("Product Name  :   "+p5.getPname());
				System.out.println("Product Qty   :   "+product.getQty());
				System.out.println("Product Price :   "+p5.getPrice());
				System.out.println("-------------------------------");
				System.out.println("Total         :   "+(product.getQty()*p5.getPrice()));
				System.out.println("-------------------------------");
				
			}else{
				tempList.add(p5);
			}
		}
		pizzas = new ArrayList<Pizza>();
		for(Pizza p6:tempList)
		{
			pizzas.add(p6);
		}
		System.out.println("Thank you.Visit Once again....");
		
	}

	@Override
	public void back() {
	PizzaManagement.main(null);		
	}
	
}
