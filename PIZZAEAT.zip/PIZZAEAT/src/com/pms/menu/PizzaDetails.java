package com.pms.menu;

import java.util.List;
import java.util.Scanner;

import com.pms.bean.Pizza;
import com.pms.daoimpl.PizzaDAOImpl;

public class PizzaDetails {
	static Scanner sc = new Scanner(System.in);
	static PizzaDAOImpl pizzaDAO = new PizzaDAOImpl();

	public static void adminMenu() {
		System.out.println("-----------------------");
		System.out.println("|   ADMIN MAIN MENU   |");
		System.out.println("-----------------------");
		System.out.println("| 1.ADD PRODUCT       |");
		System.out.println("| 2.VIEW PIZZA      |");
		System.out.println("| 3.VIEW ALL PIZZAS |");
		System.out.println("| 4.UPDATE PIZZA   |");
		System.out.println("| 5.DELETE PIZZA    |");
		System.out.println("| 6.BACK              |");
		System.out.println("-----------------------");
		System.out.println("Enter Your Choice ?");
		int choice = sc.nextInt();
		switch (choice) {
		case 1:
			pizzaDAO.addPizza();
			adminMenu();
			break;
		case 2:
			System.out.println("Enter Your Search Product Id ?");
			Pizza pizza = pizzaDAO.viewPizza(sc.nextInt());
			System.out.println("PID" + "\t" + "PNAME" + "QTY" + "\t" + "PRICE");
			System.out.println("------------------------------------");
			System.out.println(pizza);
			adminMenu();
			break;
		case 3:
			List<Pizza> pizzas = pizzaDAO.viewAllPizza();
			System.out.println("PID" + "\t" + "PNAME" + "QTY" + "\t" + "PRICE");
			System.out.println("------------------------------------");
			for (Pizza p : pizzas) {
				System.out.println(p);
			}
			adminMenu();
			break;
		case 4:
			System.out.println("Enter Updating product Id ?");
			pizzaDAO.updatePizza(sc.nextInt());
			adminMenu();
			break;
		case 5:
			System.out.println("Enter Deleting Product Id ?");
			pizzaDAO.deletePizza(sc.nextInt());
			adminMenu();
			break;
		case 6:
			pizzaDAO.back();
			break;
		default:
			System.out.println("Please select your choice range 1-6 only");

		}
	}

	public static void customerMenu() {
		System.out.println("-----------------------");
		System.out.println("|  CUSTOMER MAIN MENU   |");
		System.out.println("-----------------------");
		System.out.println("| 1.VIEW PIZZA      |");
		System.out.println("| 2.VIEW ALL PIZZAS |");
		System.out.println("| 3.BILL            |");
		System.out.println("| 4.BACK            |");
		System.out.println("| 5.PLACE ORDER     |");
		System.out.println("| 6.CANCEL ORDER    |");
		System.out.println("-----------------------");
		System.out.println("Enter Your Choice ?");
		int choice = sc.nextInt();
		switch (choice) {

		case 1:
			System.out.println("Enter Your Search PIZZA Id ?");
			Pizza product = pizzaDAO.viewPizza(sc.nextInt());
			System.out.println("PID" + "\t" + "PNAME" + "QTY" + "\t" + "PRICE");
			System.out.println("------------------------------------");
			System.out.println(product);
			customerMenu();
			break;
		case 2:
			List<Pizza> pizzas = pizzaDAO.viewAllPizza();
			System.out.println("PID" + "\t" + "PNAME" + "QTY" + "\t" + "PRICE");
			System.out.println("------------------------------------");
			for (Pizza p : pizzas) {
				System.out.println(p);
			}
			customerMenu();
			break;
		case 3:
			pizzaDAO.bill();
			break;
		case 4:
			pizzaDAO.back();
			break;
		case 5:
			System.out.println("enter id");
			int select=sc.nextInt();
			pizzaDAO.placeOrder(select);
			break;
		case 6:
			System.out.println("Enter id to be cancelled");
			int select1=sc.nextInt();
		    pizzaDAO.cancelOrder(select1);
		    break;
				
		default:
			System.out.println("Please select your choice range 1-6 only");

		}
	}

}
